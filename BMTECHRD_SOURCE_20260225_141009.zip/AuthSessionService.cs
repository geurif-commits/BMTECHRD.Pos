using System;

namespace BMTECHRD.Pos.App.Services;

/// <summary>
/// Mantiene la sesión de autenticación del usuario actual (tokens, datos).
/// Almacenamiento en memoria (fase 1).
/// </summary>
public sealed class AuthSessionService
{
    private string? _accessToken;
    private string? _refreshToken;
    private Guid _userId;
    private Guid _businessId;
    private string? _username;
    private string? _role;
    private DateTime _expiresAt;
    private object _lockObj = new object();

    public string? AccessToken => _accessToken;
    public string? RefreshToken => _refreshToken;
    public Guid UserId => _userId;
    public Guid BusinessId => _businessId;
    public string? Username => _username;
    public string? Role => _role;
    public DateTime ExpiresAt => _expiresAt;

    /// <summary>
    /// Indica si el usuario está autenticado actualmente.
    /// </summary>
    public bool IsAuthenticated => !string.IsNullOrEmpty(_accessToken) && _userId != Guid.Empty;

    /// <summary>
    /// Indica si el access token está próximo a expirar (< 5 minutos).
    /// </summary>
    public bool IsAccessTokenExpiring => DateTime.UtcNow.AddMinutes(5) >= _expiresAt;

    /// <summary>
    /// Establece la sesión con los datos de login.
    /// </summary>
    public void SetSession(
        string accessToken,
        string refreshToken,
        Guid userId,
        Guid businessId,
        string username,
        string role,
        DateTime expiresAt)
    {
        lock (_lockObj)
        {
            _accessToken = accessToken;
            _refreshToken = refreshToken;
            _userId = userId;
            _businessId = businessId;
            _username = username;
            _role = role;
            _expiresAt = expiresAt;
        }
    }

    /// <summary>
    /// Actualiza el access token (refresh).
    /// </summary>
    public void UpdateAccessToken(string newAccessToken, DateTime newExpiresAt)
    {
        lock (_lockObj)
        {
            _accessToken = newAccessToken;
            _expiresAt = newExpiresAt;
        }
    }

    /// <summary>
    /// Actualiza ambos tokens (refresh token rotation).
    /// </summary>
    public void UpdateTokens(string newAccessToken, string newRefreshToken, DateTime newExpiresAt)
    {
        lock (_lockObj)
        {
            _accessToken = newAccessToken;
            _refreshToken = newRefreshToken;
            _expiresAt = newExpiresAt;
        }
    }

    /// <summary>
    /// Limpia la sesión (logout).
    /// </summary>
    public void Clear()
    {
        lock (_lockObj)
        {
            _accessToken = null;
            _refreshToken = null;
            _userId = Guid.Empty;
            _businessId = Guid.Empty;
            _username = null;
            _role = null;
            _expiresAt = DateTime.MinValue;
        }
    }
}
