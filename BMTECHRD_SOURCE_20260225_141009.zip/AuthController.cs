using BMTECHRD.Pos.Application.Abstractions.Security;
using BMTECHRD.Pos.Application.DTOs;
using BMTECHRD.Pos.Infrastructure.Persistence;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace BMTECHRD.Pos.Api.Controllers;

[ApiController]
[Route("api/auth")]
public sealed class AuthController : ControllerBase
{
    private readonly AppDbContext _ctx;
    private readonly IPasswordHasher _hasher;
    private readonly ITokenService _tokenService;

    public AuthController(AppDbContext ctx, IPasswordHasher hasher, ITokenService tokenService)
    {
        _ctx = ctx;
        _hasher = hasher;
        _tokenService = tokenService;
    }

    /// <summary>
    /// POST /api/auth/login
    /// Autentica un usuario y retorna access + refresh tokens.
    /// </summary>
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest req)
    {
        // Validar negocio
        var business = await _ctx.Businesses.FindAsync(req.BusinessId);
        if (business == null) 
            return NotFound("Business not found");

        // Buscar usuario
        var user = await _ctx.Users.FirstOrDefaultAsync(
            u => u.BusinessId == req.BusinessId && u.Username == req.Username);
        if (user == null) 
            return Unauthorized("Invalid credentials");

        // Verificar contraseña
        var ok = _hasher.Verify(req.Password, user.PasswordHash ?? string.Empty);
        if (!ok) 
            return Unauthorized("Invalid credentials");

        // Generar tokens
        var accessToken = _tokenService.CreateAccessToken(user, req.BusinessId);
        var (refreshTokenRaw, refreshTokenEntity) = await _tokenService.CreateRefreshTokenAsync(
            user,
            req.BusinessId,
            deviceId: req.DeviceId,
            ipAddress: HttpContext.Connection.RemoteIpAddress?.ToString());

        // Registrar en auditoría
        var auditLog = new BMTECHRD.Pos.Domain.Entities.AuditLog
        {
            Id = Guid.NewGuid(),
            BusinessId = req.BusinessId,
            ActorUserId = user.Id,
            Action = "AUTH_LOGIN",
            EntityType = "User",
            EntityId = user.Id,
            CreatedAt = DateTime.UtcNow
        };
        _ctx.AuditLogs.Add(auditLog);
        await _ctx.SaveChangesAsync();

        var resp = new LoginResponse
        {
            AccessToken = accessToken,
            RefreshToken = refreshTokenRaw,
            UserId = user.Id,
            BusinessId = req.BusinessId,
            Username = user.Username,
            Role = user.Role.ToString(),
            ExpiresAt = refreshTokenEntity.ExpiresAt
        };

        return Ok(resp);
    }

    /// <summary>
    /// POST /api/auth/refresh
    /// Renueva el access token usando un refresh token (con rotación).
    /// </summary>
    [HttpPost("refresh")]
    public async Task<IActionResult> Refresh([FromBody] RefreshTokenRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.RefreshToken))
            return BadRequest("Refresh token is required");

        // Validar refresh token
        var refreshToken = await _tokenService.ValidateRefreshTokenAsync(req.RefreshToken);
        if (refreshToken == null)
            return Unauthorized("Invalid or expired refresh token");

        // Obtener usuario
        var user = await _ctx.Users.FindAsync(refreshToken.UserId);
        if (user == null)
            return Unauthorized("User not found");

        // Crear nuevo access token + refresh token (rotación)
        var newAccessToken = _tokenService.CreateAccessToken(user, refreshToken.BusinessId);
        var (newRefreshTokenRaw, newRefreshTokenEntity) = await _tokenService.CreateRefreshTokenAsync(
            user,
            refreshToken.BusinessId,
            deviceId: req.DeviceId ?? refreshToken.DeviceId,
            ipAddress: HttpContext.Connection.RemoteIpAddress?.ToString());

        // Revocar token anterior (marca como reemplazado)
        await _tokenService.RevokeRefreshTokenAsync(refreshToken.Id, newRefreshTokenEntity.Id);

        // Registrar en auditoría
        var auditLog = new BMTECHRD.Pos.Domain.Entities.AuditLog
        {
            Id = Guid.NewGuid(),
            BusinessId = refreshToken.BusinessId,
            ActorUserId = user.Id,
            Action = "AUTH_REFRESH",
            EntityType = "User",
            EntityId = user.Id,
            CreatedAt = DateTime.UtcNow
        };
        _ctx.AuditLogs.Add(auditLog);
        await _ctx.SaveChangesAsync();

        var resp = new LoginResponse
        {
            AccessToken = newAccessToken,
            RefreshToken = newRefreshTokenRaw,
            UserId = user.Id,
            BusinessId = refreshToken.BusinessId,
            Username = user.Username,
            Role = user.Role.ToString(),
            ExpiresAt = newRefreshTokenEntity.ExpiresAt
        };

        return Ok(resp);
    }

    /// <summary>
    /// POST /api/auth/logout
    /// Revoca el refresh token actual.
    /// </summary>
    [Authorize]
    [HttpPost("logout")]
    public async Task<IActionResult> Logout([FromBody] LogoutRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.RefreshToken))
            return BadRequest("Refresh token is required");

        // Validar y revocar
        var refreshToken = await _tokenService.ValidateRefreshTokenAsync(req.RefreshToken);
        if (refreshToken != null)
        {
            await _tokenService.RevokeRefreshTokenAsync(refreshToken.Id);

            // Registrar en auditoría
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (Guid.TryParse(userId, out var userIdGuid))
            {
                var auditLog = new BMTECHRD.Pos.Domain.Entities.AuditLog
                {
                    Id = Guid.NewGuid(),
                    BusinessId = refreshToken.BusinessId,
                    ActorUserId = userIdGuid,
                    Action = "AUTH_LOGOUT",
                    EntityType = "User",
                    EntityId = userIdGuid,
                    CreatedAt = DateTime.UtcNow
                };
                _ctx.AuditLogs.Add(auditLog);
                await _ctx.SaveChangesAsync();
            }
        }

        return Ok(new { message = "Logged out successfully" });
    }

    /// <summary>
    /// GET /api/auth/me
    /// Retorna los claims del usuario autenticado actual.
    /// </summary>
    [Authorize]
    [HttpGet("me")]
    public IActionResult Me()
    {
        var userId = User.FindFirst("sub")?.Value;
        var businessId = User.FindFirst("bid")?.Value;
        var role = User.FindFirst("role")?.Value;
        var username = User.FindFirst("uname")?.Value;

        if (!Guid.TryParse(userId, out var userIdGuid) || !Guid.TryParse(businessId, out var businessIdGuid))
            return Unauthorized();

        var resp = new
        {
            userId = userIdGuid,
            businessId = businessIdGuid,
            role,
            username
        };

        return Ok(resp);
    }
}

/// <summary>
/// DTO para login request.
/// </summary>
public class LoginRequest
{
    public Guid BusinessId { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string? DeviceId { get; set; }
}

/// <summary>
/// DTO para refresh token request.
/// </summary>
public class RefreshTokenRequest
{
    public string RefreshToken { get; set; } = string.Empty;
    public string? DeviceId { get; set; }
}

/// <summary>
/// DTO para logout request.
/// </summary>
public class LogoutRequest
{
    public string RefreshToken { get; set; } = string.Empty;
}

/// <summary>
/// DTO para login response.
/// </summary>
public class LoginResponse
{
    public string AccessToken { get; set; } = string.Empty;
    public string RefreshToken { get; set; } = string.Empty;
    public Guid UserId { get; set; }
    public Guid BusinessId { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public DateTime ExpiresAt { get; set; }
}
