using System.IdentityModel.Tokens.Jwt;
using System.Security.Cryptography;
using System.Text;
using BMTECHRD.Pos.Application.Abstractions.Security;
using BMTECHRD.Pos.Domain.Entities;
using BMTECHRD.Pos.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace BMTECHRD.Pos.Infrastructure.Auth;

/// <summary>
/// Implementación de JWT tokens con refresh token rotation.
/// </summary>
public sealed class JwtTokenService : ITokenService
{
    private readonly IConfiguration _config;
    private readonly AppDbContext _dbContext;

    private readonly string _issuer;
    private readonly string _audience;
    private readonly int _accessTokenMinutes;
    private readonly int _refreshTokenDays;
    private readonly byte[] _signingKeyBytes;

    public JwtTokenService(IConfiguration config, AppDbContext dbContext)
    {
        _config = config;
        _dbContext = dbContext;

        // Leer configuración desde appsettings
        _issuer = _config["Jwt:Issuer"] ?? "BMTECHRD.Pos.Api";
        _audience = _config["Jwt:Audience"] ?? "BMTECHRD.Pos.App";
        _accessTokenMinutes = int.Parse(_config["Jwt:AccessTokenMinutes"] ?? "30");
        _refreshTokenDays = int.Parse(_config["Jwt:RefreshTokenDays"] ?? "30");

        var signingKey = _config["Jwt:SigningKey"] ?? throw new InvalidOperationException("Jwt:SigningKey not configured");
        if (signingKey.Length < 32)
            throw new InvalidOperationException("Jwt:SigningKey debe tener al menos 32 caracteres");

        _signingKeyBytes = Encoding.UTF8.GetBytes(signingKey);
    }

    /// <summary>
    /// Crea un access token JWT (corta duración, sin refresh token en claims).
    /// </summary>
    public string CreateAccessToken(User user, Guid businessId)
    {
        var tokenHandler = new JwtSecurityTokenHandler();
        var expiresAt = DateTime.UtcNow.AddMinutes(_accessTokenMinutes);

        var claims = new List<System.Security.Claims.Claim>
        {
            new("sub", user.Id.ToString()),                      // subject = userId
            new("bid", businessId.ToString()),                   // businessId
            new("role", user.Role.ToString()),                   // user role
            new("uname", user.Username),                         // username
        };

        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new System.Security.Claims.ClaimsIdentity(claims),
            Expires = expiresAt,
            Issuer = _issuer,
            Audience = _audience,
            SigningCredentials = new SigningCredentials(
                new SymmetricSecurityKey(_signingKeyBytes),
                SecurityAlgorithms.HmacSha256Signature)
        };

        var token = tokenHandler.CreateToken(tokenDescriptor);
        return tokenHandler.WriteToken(token);
    }

    /// <summary>
    /// Crea un refresh token: genera token raw, lo hashea y lo persiste.
    /// </summary>
    public async Task<(string RawToken, RefreshToken Entity)> CreateRefreshTokenAsync(
        User user,
        Guid businessId,
        string? deviceId = null,
        string? ipAddress = null)
    {
        // Generar token raw (64 bytes = 88 chars en base64)
        using (var rng = RandomNumberGenerator.Create())
        {
            var tokenBytes = new byte[64];
            rng.GetBytes(tokenBytes);
            var rawToken = Convert.ToBase64String(tokenBytes);

            // Hashear para almacenar
            var tokenHash = HashToken(rawToken);

            var refreshToken = new RefreshToken
            {
                BusinessId = businessId,
                UserId = user.Id,
                TokenHash = tokenHash,
                CreatedAt = DateTime.UtcNow,
                ExpiresAt = DateTime.UtcNow.AddDays(_refreshTokenDays),
                RevokedAt = null,
                ReplacedByTokenId = null,
                DeviceId = deviceId,
                IpAddress = ipAddress
            };

            _dbContext.RefreshTokens.Add(refreshToken);
            await _dbContext.SaveChangesAsync();

            return (rawToken, refreshToken);
        }
    }

    /// <summary>
    /// Valida un refresh token: busca su hash, verifica expiración y revocación.
    /// </summary>
    public async Task<RefreshToken?> ValidateRefreshTokenAsync(string rawToken)
    {
        if (string.IsNullOrWhiteSpace(rawToken))
            return null;

        var tokenHash = HashToken(rawToken);
        var refreshToken = await _dbContext.RefreshTokens
            .FirstOrDefaultAsync(rt => rt.TokenHash == tokenHash);

        if (refreshToken == null || !refreshToken.IsActive)
            return null;

        return refreshToken;
    }

    /// <summary>
    /// Revoca un refresh token existente.
    /// </summary>
    public async Task RevokeRefreshTokenAsync(Guid tokenId, Guid? replacedByTokenId = null)
    {
        var token = await _dbContext.RefreshTokens.FindAsync(tokenId);
        if (token != null)
        {
            token.RevokedAt = DateTime.UtcNow;
            token.ReplacedByTokenId = replacedByTokenId;
            await _dbContext.SaveChangesAsync();
        }
    }

    /// <summary>
    /// Hashea un token raw usando SHA256.
    /// </summary>
    public string HashToken(string rawToken)
    {
        using (var sha256 = SHA256.Create())
        {
            var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(rawToken));
            return Convert.ToBase64String(hashedBytes);
        }
    }
}
