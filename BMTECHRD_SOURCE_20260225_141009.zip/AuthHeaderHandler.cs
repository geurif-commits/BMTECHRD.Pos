using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace BMTECHRD.Pos.App.Services;

/// <summary>
/// DelegatingHandler que inyecta el JWT access token en cada request.
/// También maneja auto-refresh si recibe 401.
/// </summary>
public sealed class AuthHeaderHandler : DelegatingHandler
{
    private readonly AuthSessionService _session;
    private readonly ApiClient _apiClient;

    public AuthHeaderHandler(AuthSessionService session, ApiClient apiClient)
    {
        _session = session;
        _apiClient = apiClient;
    }

    protected override async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        // Inyectar token si autenticado
        if (_session.IsAuthenticated && _session.AccessToken != null)
        {
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue(
                "Bearer",
                _session.AccessToken);
        }

        var response = await base.SendAsync(request, cancellationToken);

        // Si 401 y tenemos refresh token, intentar renovar
        if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized && 
            _session.RefreshToken != null &&
            !request.RequestUri?.PathAndQuery.Contains("/api/auth/login") == true)
        {
            // Intentar refresh
            var refreshed = await _apiClient.RefreshTokenAsync(_session.RefreshToken);
            if (refreshed != null)
            {
                // Actualizar sesión
                _session.UpdateTokens(
                    refreshed.AccessToken,
                    refreshed.RefreshToken,
                    refreshed.ExpiresAt);

                // Reintentar request original con nuevo token
                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue(
                    "Bearer",
                    _session.AccessToken);
                response = await base.SendAsync(request, cancellationToken);
            }
            else
            {
                // Refresh falló: logout
                _session.Clear();
            }
        }

        return response;
    }
}
