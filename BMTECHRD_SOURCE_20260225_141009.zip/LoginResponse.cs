namespace BMTECHRD.Pos.Application.DTOs;

public sealed class LoginResponse
{
    public required string AccessToken { get; set; }
    public required string RefreshToken { get; set; }
    public required System.Guid UserId { get; set; }
    public required System.Guid BusinessId { get; set; }
    public required string Username { get; set; }
    public required string Role { get; set; }
    public System.DateTime ExpiresAt { get; set; }
}
