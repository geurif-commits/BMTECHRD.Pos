﻿using System.Configuration;
using System.Data;
using System.Windows;
using BMTECHRD.Pos.App.Services;

namespace BMTECHRD.Pos.App
{
    public partial class App : System.Windows.Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            var configService = new LocalDeviceConfigService();
            var config = configService.Load();

            if (config == null)
            {
                // Primera vez: mostrar selección de modo
                var selectionWindow = new DeviceModeSelectionWindow();
                selectionWindow.ShowDialog();
                // Luego de seleccionar, la app se reinicia
            }
            else
            {
                // Ya hay configuración, continuar normalmente
                this.StartupUri = new System.Uri("MainWindow.xaml");
            }
        }
    }
}

