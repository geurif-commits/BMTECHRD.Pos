﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Net.Http;
using BMTECHRD.Pos.App.Core;
using BMTECHRD.Pos.App.Models;
using BMTECHRD.Pos.App.Services;

namespace BMTECHRD.Pos.App
{
    public partial class MainWindow : Window
    {
        private DeviceMode _deviceMode;
        private LocalDeviceConfigService _configService;
        private AuthSessionService? _authSession;

        public MainWindow()
        {
            InitializeComponent();
            _configService = new LocalDeviceConfigService();
        }

        protected override void OnContentRendered(System.EventArgs e)
        {
            base.OnContentRendered(e);

            var config = _configService.Load();
            if (config == null)
            {
                this.Close();
                return;
            }

            _deviceMode = config.Mode;

            // Crear sesión de autenticación (BLOQUE 7)
            _authSession = new AuthSessionService();

            // Crear HttpClient con auth handler
            var handler = new AuthHeaderHandler(_authSession, null!);
            var innerHandler = new HttpClientHandler();
            handler.InnerHandler = innerHandler;
            var http = new System.Net.Http.HttpClient(handler) 
            { 
                BaseAddress = new System.Uri("https://localhost:5001/") 
            };

            var api = new Services.ApiClient(http);

            // Reasignar handler con referencia a api (permite refresh)
            handler = new AuthHeaderHandler(_authSession, api);
            http = new System.Net.Http.HttpClient(handler) 
            { 
                BaseAddress = new System.Uri("https://localhost:5001/") 
            };
            api = new Services.ApiClient(http);

            // show start view for business selection and login
            var start = new Views.StartView();
            start.Initialize(api);
            start.OnLoginSuccess += session =>
            {
                // Guardar sesión de auth (BLOQUE 7)
                _authSession!.SetSession(
                    session.AccessToken,
                    session.RefreshToken,
                    session.UserId,
                    session.BusinessId,
                    session.Username,
                    session.Role,
                    session.ExpiresAt);

                // setup SignalR client and join business group
                var baseUrl = "https://localhost:5001/";
                var signalR = new Services.SignalRClient(baseUrl, () => Task.FromResult(_authSession!.AccessToken));
                // Pasar token para SignalR (BLOQUE 7)
                signalR.ConnectAsync().GetAwaiter().GetResult();
                signalR.JoinBusinessAsync(session.BusinessId).GetAwaiter().GetResult();

                // Validar rol según device mode
                if (!ValidateRoleForDeviceMode(session.Role))
                {
                    // Mostrar AccessDeniedView
                    var accessDenied = new Views.AccessDeniedView();
                    accessDenied.Initialize(signalR, session.BusinessId);
                    this.Content = accessDenied;
                    return;
                }

                // Cargar vista según device mode
                LoadViewForDeviceMode(api, signalR, session);
            };

            this.Content = start;
        }

        private bool ValidateRoleForDeviceMode(string? role)
        {
            var userRole = role?.ToUpperInvariant() ?? "";

            return _deviceMode switch
            {
                DeviceMode.Server => userRole == "ADMIN" || userRole == "SUPERVISOR",
                DeviceMode.Cashier => userRole == "CASHIER" || userRole == "ADMIN" || userRole == "SUPERVISOR",
                DeviceMode.Kitchen => userRole == "KITCHEN" || userRole == "ADMIN" || userRole == "SUPERVISOR",
                DeviceMode.Bar => userRole == "BAR" || userRole == "ADMIN" || userRole == "SUPERVISOR",
                DeviceMode.Floor => userRole == "WAITER" || userRole == "CASHIER" || userRole == "ADMIN" || userRole == "SUPERVISOR",
                _ => false
            };
        }

        private void LoadViewForDeviceMode(Services.ApiClient api, Services.SignalRClient signalR, SessionModel session)
        {
            switch (_deviceMode)
            {
                case DeviceMode.Server:
                    LoadServerView(api, signalR, session);
                    break;

                case DeviceMode.Cashier:
                    LoadCashierView(api, signalR, session);
                    break;

                case DeviceMode.Kitchen:
                    // CORRECCIÓN CRÍTICA ETAPA 8.1: pasar session.BusinessId real
                    LoadKitchenView(api, signalR, session.BusinessId);
                    break;

                case DeviceMode.Bar:
                    // CORRECCIÓN CRÍTICA ETAPA 8.1: pasar session.BusinessId real
                    LoadBarView(api, signalR, session.BusinessId);
                    break;

                case DeviceMode.Floor:
                    LoadFloorView(api, signalR, session);
                    break;
            }
        }

        private void LoadServerView(Services.ApiClient api, Services.SignalRClient signalR, SessionModel session)
        {
            var adminView = new Views.Admin.AdminView();
            adminView.Initialize(api, session.BusinessId, session.UserId, signalR, session.Role);
            this.Content = adminView;
        }

        private void LoadCashierView(Services.ApiClient api, Services.SignalRClient signalR, SessionModel session)
        {
            var tab = new TabControl();

            // Caja + Turnos para Cashier
            var cashView = new Views.CashierView();
            cashView.Initialize(api, signalR, session.BusinessId, session.UserId);
            tab.Items.Add(new TabItem { Header = "Caja", Content = cashView });

            // Mostrar Admin si es SUPERVISOR
            if (session.Role?.ToUpperInvariant() == "SUPERVISOR")
            {
                var adminView = new Views.Admin.AdminView();
                adminView.Initialize(api, session.BusinessId, session.UserId);
                tab.Items.Add(new TabItem { Header = "Admin", Content = adminView });
            }

            tab.SelectedIndex = 0;
            this.Content = tab;
        }

        private void LoadKitchenView(Services.ApiClient api, Services.SignalRClient signalR, System.Guid businessId)
        {
            var kitchenView = new Views.KitchenQueueView();
            // CORRECCIÓN CRÍTICA ETAPA 8.1: pasar businessId real (no Guid.Empty)
            kitchenView.Initialize(api, signalR, businessId);
            this.Content = kitchenView;
        }

        private void LoadBarView(Services.ApiClient api, Services.SignalRClient signalR, System.Guid businessId)
        {
            var barView = new Views.BarQueueView();
            // CORRECCIÓN CRÍTICA ETAPA 8.1: pasar businessId real (no Guid.Empty)
            barView.Initialize(api, signalR, businessId);
            this.Content = barView;
        }

        private void LoadFloorView(Services.ApiClient api, Services.SignalRClient signalR, SessionModel session)
        {
            var tablesView = new Views.TablesMapView();
            tablesView.Initialize(api, signalR, session.BusinessId, session.UserId);
            this.Content = tablesView;
        }
    }
}

