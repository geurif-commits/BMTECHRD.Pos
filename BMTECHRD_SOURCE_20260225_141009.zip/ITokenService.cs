using BMTECHRD.Pos.Domain.Entities;

namespace BMTECHRD.Pos.Application.Abstractions.Security;

/// <summary>
/// Interfaz para gestión de tokens JWT y refresh tokens.
/// </summary>
public interface ITokenService
{
    /// <summary>
    /// Crea un access token (JWT corta duración).
    /// </summary>
    string CreateAccessToken(User user, Guid businessId);

    /// <summary>
    /// Crea un refresh token seguro y lo persiste en BD.
    /// Retorna el token en claro + la entidad almacenada.
    /// </summary>
    Task<(string RawToken, RefreshToken Entity)> CreateRefreshTokenAsync(
        User user,
        Guid businessId,
        string? deviceId = null,
        string? ipAddress = null);

    /// <summary>
    /// Valida un refresh token en claro contra su hash en BD.
    /// Retorna la entidad si es válida (activa, no expirada, no revocada).
    /// </summary>
    Task<RefreshToken?> ValidateRefreshTokenAsync(string rawToken);

    /// <summary>
    /// Revoca un refresh token existente.
    /// </summary>
    Task RevokeRefreshTokenAsync(Guid tokenId, Guid? replacedByTokenId = null);

    /// <summary>
    /// Genera hash SHA256 de un token raw.
    /// </summary>
    string HashToken(string rawToken);
}